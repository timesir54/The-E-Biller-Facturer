﻿namespace The_E_Biller_Facturer
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            nombreColumn = new DataGridViewTextBoxColumn();
            fechaColumn = new DataGridViewTextBoxColumn();
            sueldoColumn = new DataGridViewTextBoxColumn();
            pagoColumn = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { nombreColumn, fechaColumn, sueldoColumn, pagoColumn });
            dataGridView1.Location = new Point(206, 159);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(449, 150);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // nombreColumn
            // 
            nombreColumn.HeaderText = "Nombre del empleado";
            nombreColumn.Name = "nombreColumn";
            // 
            // fechaColumn
            // 
            fechaColumn.HeaderText = "Fecha";
            fechaColumn.Name = "fechaColumn";
            // 
            // sueldoColumn
            // 
            sueldoColumn.HeaderText = "Sueldo";
            sueldoColumn.Name = "sueldoColumn";
            // 
            // pagoColumn
            // 
            pagoColumn.HeaderText = "Pago";
            pagoColumn.Name = "pagoColumn";
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Name = "Form4";
            Text = "Form4";
            Load += Form4_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn nombreColumn;
        private DataGridViewTextBoxColumn fechaColumn;
        private DataGridViewTextBoxColumn sueldoColumn;
        private DataGridViewTextBoxColumn pagoColumn;
    }
}