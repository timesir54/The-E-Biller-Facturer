﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_E_Biller_Facturer
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();




        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            // Crear columnas en el DataGridView
            DataGridViewTextBoxColumn nombreColumn = new DataGridViewTextBoxColumn();
            nombreColumn.HeaderText = "Nombre de empleado";
            DataGridViewTextBoxColumn fechaColumn = new DataGridViewTextBoxColumn();
            fechaColumn.HeaderText = "Fecha";
            DataGridViewTextBoxColumn sueldoColumn = new DataGridViewTextBoxColumn();
            sueldoColumn.HeaderText = "Sueldo";
            DataGridViewTextBoxColumn pagoColumn = new DataGridViewTextBoxColumn();
            pagoColumn.HeaderText = "Pago";

            dataGridView1.Columns.Add(nombreColumn);
            dataGridView1.Columns.Add(fechaColumn);
            dataGridView1.Columns.Add(sueldoColumn);
            dataGridView1.Columns.Add(pagoColumn);
        }
    }
}
