﻿using System;
using System.Collections.Generic;

namespace DAL.Models
{
    public partial class In
    {
        public int Lonid { get; set; }
        public string Lonname { get; set; } = null!;
        public string Lonpassword { get; set; } = null!;
    }
}
